﻿using System;

namespace ClassBoxData
{
    public class Box
    {
        private const double SIDE_MIN_VALUE = 0;
        private const string INVALID_SIDE_MESSAGE = "{0} cannot be zero or negative.";

        private double length;
        private double width;
        private double height;

        public Box(double length,double width,double height)
        {
            this.Length = length;
            this.Width = width;
            this.Height = height;
        }

        public double Length
        {
            get => this.length;
            private set
            {
                this.ValidateMinValue(value, nameof(this.Length));

                this.length = value;
            }
        }

        public double Width
        {
            get => this.width;
            private set
            {
                this.ValidateMinValue(value, nameof(this.Width));

                this.width = value;
            }
        }

        public double Height
        {
            get => this.height;
            private set
            {
                this.ValidateMinValue(value, nameof(this.Height));

                this.height = value;
            }
        }

        public double CalculateSurfaceArea()
        {
            var surfaceArea =
                2 * ((this.Length * this.Width) + (this.Length * this.Height) + (this.Height * this.Width));

            return surfaceArea;
        }

        public double CalculateLateralSurfaceArea()
        {
            var lateralSurfaceArea =
                2 * ((this.Length * this.Height) + (this.Height * this.Width));

            return lateralSurfaceArea;
        }

        public double CalculateVolume()
        {
            var volume =this.Length*this.Height*this.Width ;

            return volume;
        }

        private void ValidateMinValue(double value, string sideName)
        {
            if (value <= SIDE_MIN_VALUE)
            {
                throw new ArgumentException(string.Format(INVALID_SIDE_MESSAGE, sideName));
            }
        }
    }
}
