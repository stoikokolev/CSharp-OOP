// Use this file for your unit tests.
// When you are ready to submit, REMOVE all using statements to Festival Manager (entities/controllers/etc)
// Test ONLY the Stage class. 



namespace FestivalManager.Tests
{
    using NUnit.Framework;
    using System;

    [TestFixture]
	public class StageTests
    {
        private static Song song1;
        private static Song song2;
        private static Performer perf1;
        private static Performer perf2;
        private static Stage stage;

        [SetUp]
        public void Setup()
        {
            song1=new Song("AA", TimeSpan.Zero);
            song2=new Song("AB", TimeSpan.MaxValue);
            perf1=new Performer("Ivan", "Ivanov", 18);
            perf2=new Performer("Ivan2", "Ivanov2", 17);
            stage=new Stage();

        }

		[Test]
	    public void test1()
        {
            var a = song1.ToString();

            Assert.AreEqual("AA", song1.Name);
        }

        [Test]
        public void test2()
        {
            TimeSpan a = new TimeSpan(00,00,00);

            Assert.AreEqual(a, song1.Duration);
        }

        [Test]
        public void test3()
        {
            TimeSpan a = new TimeSpan(00, 00, 00);

            Assert.AreEqual($"AA (00:00)", song1.ToString());
        }

        [Test]
        public void test4()
        {
            

            Assert.AreEqual("Ivan Ivanov", perf1.FullName);
        }

        [Test]
        public void test5()
        {


            Assert.AreEqual(18, perf1.Age);
        }

        [Test]
        public void test6()
        {


            Assert.AreEqual(0, perf1.SongList.Count);
        }

        [Test]
        public void test7()
        {


            Assert.AreEqual("Ivan Ivanov", perf1.ToString());
        }

        [Test]
        public void test8()
        {


            Assert.AreEqual(0, stage.Performers.Count);
        }

        [Test]
        public void test9()
        {
            stage.AddPerformer(perf1);

            Assert.AreEqual(1, stage.Performers.Count);
        }

        [Test]
        public void test10()
        {
            Assert.That(() => { stage.AddPerformer(perf2); }, Throws.ArgumentException);
        }

        [Test]
        public void test11()
        {
            Assert.That(() => { stage.AddPerformer(null); }, Throws.ArgumentNullException);
        }

        [Test]
        public void test12()
        {
            Assert.That(() => { stage.AddSong(song1); }, Throws.ArgumentException);
        }

        [Test]
        public void test13()
        {
            stage.AddSong(song2);
            stage.AddPerformer(perf1);
           var a= stage.AddSongToPerformer("AB", "Ivan Ivanov");

            Assert.AreEqual(1, perf1.SongList.Count);
            Assert.AreEqual("AB (48:05) will be performed by Ivan Ivanov",a);
        }

        [Test]
        public void test14()
        {
            Assert.That(() => { stage.AddSong(null); }, Throws.ArgumentNullException);
        }

        [Test]
        public void test15()
        {
            stage.AddSong(song2);
            stage.AddPerformer(perf1);
            stage.AddSongToPerformer("AB", "Ivan Ivanov");
            var a = stage.Play();
            Assert.AreEqual($"1 performers played 1 songs",a);
        }

        [Test]
        public void test16()
        {
            stage.AddSong(song2);
            stage.AddPerformer(perf1);
           
           Assert.That(() => { stage.AddSongToPerformer("AC", "Ivan Ivanov");}, Throws.ArgumentException);
        }

        [Test]
        public void test17()
        {
            stage.AddSong(song2);
            stage.AddPerformer(perf1);

            Assert.That(() => { stage.AddSongToPerformer("AB", "Ivan3 Ivanov"); }, Throws.ArgumentException);
        }

    }
}