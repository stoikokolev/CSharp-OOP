﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WarCroft.Constants;
using WarCroft.Entities.Characters.Contracts;
using WarCroft.Entities.Items;

namespace WarCroft.Core
{
	public class WarController
    {
        private ICollection<Character> party;
        private ICollection<Item> itemPool;

		public WarController()
		{
			this.party=new List<Character>();
			this.itemPool=new List<Item>();
		}

		public string JoinParty(string[] args)
        {
            var characterType = args[0];
            var name = args[1];
            Character charachter=null;
            if (characterType == "Warrior")
            {
				charachter=new Warrior(name);
            }
			else if (characterType == "Priest")
            {
                charachter = new Priest(name);
            }
            else
            {
                throw new ArgumentException(string.Format(ExceptionMessages.InvalidCharacterType,characterType));
            }
			//double
			this.party.Add(charachter);

            return string.Format(SuccessMessages.JoinParty, name);
        }

		public string AddItemToPool(string[] args)
        {
            var name = args[0];
            
            Item item = null;

            if (name == "FirePotion")
            {
                item = new FirePotion();
            }
            else if (name == "HealthPotion")
            {
                item = new HealthPotion();
            }
            else
            {
                throw new ArgumentException(string.Format(ExceptionMessages.InvalidItem, name));
            }
            //double
            this.itemPool.Add(item);

            return string.Format(SuccessMessages.AddItemToPool, name);
        }

		public string PickUpItem(string[] args)
        {
            var name = args[0];

            var character = this.party.FirstOrDefault(x => x.Name == name);

            if (character is null)
            {
                throw new ArgumentException(string.Format(ExceptionMessages.CharacterNotInParty,name));
            }

            if (this.itemPool.Count == 0)
            {
                throw new InvalidOperationException(ExceptionMessages.ItemPoolEmpty);
            }

            var item = this.itemPool.Last();
            this.itemPool.Remove(item);
            character.Bag.AddItem(item);

            return string.Format(SuccessMessages.PickUpItem, name, item.GetType().Name);
        }

		public string UseItem(string[] args)
        {
            var characterName = args[0];
            var itemName = args[1];

            var character = this.party.FirstOrDefault(x => x.Name == characterName);

            if (character is null)
            {
                throw new ArgumentException(string.Format(ExceptionMessages.CharacterNotInParty, characterName));
            }

            var item = character.Bag.GetItem(itemName);
            item.AffectCharacter(character);

            return string.Format(SuccessMessages.UsedItem, characterName, itemName);
        }

		public string GetStats()
		{
            var sb = new StringBuilder();
            foreach (var character in this.party
                .OrderByDescending(x=>x.IsAlive)
                .ThenByDescending(x=>x.Health))
            {
                string status = "";
                if (character.IsAlive)
                {
                    status = "Alive";
                }
                else
                {
                    status = "Dead";
                }

                sb.AppendLine(string.Format(SuccessMessages.CharacterStats,
                    character.Name, character.Health, character.BaseHealth, character.Armor, character.BaseArmor,
                    status));
            }

            return sb.ToString().TrimEnd();
        }

		public string Attack(string[] args)
        {
            var attackerName = args[0];
            var receiverName = args[1];

            var attacker = this.party.FirstOrDefault(x => x.Name == attackerName);
            if (attacker is null)
            {
                throw new ArgumentException(string.Format(ExceptionMessages.CharacterNotInParty, attackerName));
            }

            var receiver = this.party.FirstOrDefault(x => x.Name == receiverName);
            if (receiver is null)
            {
                throw new ArgumentException(string.Format(ExceptionMessages.CharacterNotInParty, receiverName));
            }
            //is alive
            if (attacker is Warrior att && att.IsAlive && receiver.IsAlive)
            {
                att.Attack(receiver);
            }
            else
            {
                throw new ArgumentException(string.Format(ExceptionMessages.AttackFail,attackerName));
            }

            if (receiver.IsAlive)
            {
                return string.Format(SuccessMessages.AttackCharacter, attackerName, receiverName,
                    attacker.AbilityPoints, receiverName, receiver.Health, receiver.BaseHealth, receiver.Armor,
                    receiver.BaseArmor);
            }
            else
            {
                return string.Format(SuccessMessages.AttackKillsCharacter, receiverName);
            }
        }

		public string Heal(string[] args)
        {
            var healerName = args[0];
            var healingReceiverName = args[1];

            var healer = this.party.FirstOrDefault(x => x.Name == healerName);
            if (healer is null)
            {
                throw new ArgumentException(string.Format(ExceptionMessages.CharacterNotInParty, healerName));
            }

            var receiver = this.party.FirstOrDefault(x => x.Name == healingReceiverName);
            if (receiver is null)
            {
                throw new ArgumentException(string.Format(ExceptionMessages.CharacterNotInParty, healingReceiverName));
            }

            if (healer is Priest priest && healer.IsAlive && receiver.IsAlive)
            {
               priest.Heal(receiver);
            }
            else
            {
                throw new ArgumentException(string.Format(ExceptionMessages.HealerCannotHeal,healerName));
            }

            return string.Format(SuccessMessages.HealCharacter, healerName, healingReceiverName, healer.AbilityPoints,
                healingReceiverName, receiver.Health);
        }
	}
}
