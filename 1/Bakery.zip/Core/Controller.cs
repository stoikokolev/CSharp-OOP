﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Bakery.Core.Contracts;
using Bakery.Models.BakedFoods;
using Bakery.Models.BakedFoods.Contracts;
using Bakery.Models.Drinks;
using Bakery.Models.Drinks.Contracts;
using Bakery.Models.Tables;
using Bakery.Models.Tables.Contracts;
using Bakery.Utilities.Messages;

namespace Bakery.Core
{
    public class Controller : IController
    {
        private ICollection<IBakedFood> bakedFoods;
        private ICollection<IDrink> drinks;
        private ICollection<ITable> tables;
        private decimal income;

        public Controller()
        {
            this.bakedFoods = new List<IBakedFood>();
            this.drinks = new List<IDrink>();
            this.tables = new List<ITable>();
            this.income = 0m;
        }

        public string AddFood(string type, string name, decimal price)
        {
            IBakedFood food = null;
            if (type == "Bread")
            {
                food = new Bread(name, price);
            }
            else if (type == "Cake")
            {
                food = new Cake(name, price);
            }


            bakedFoods.Add(food);

            // return $"Added {name} ({food.GetType().Name}) to the menu";
            return string.Format(OutputMessages.FoodAdded, name, type);
        }

        public string AddDrink(string type, string name, int portion, string brand)
        {
            IDrink drink = null;
            if (type == "Tea")
            {
                drink = new Tea(name, portion, brand);
            }
            else if (type == "Water")
            {
                drink = new Water(name, portion, brand);
            }


            drinks.Add(drink);

            return string.Format(OutputMessages.DrinkAdded, name, brand);
            // return $"Added {name} ({brand}) to the drink menu";
        }

        public string AddTable(string type, int tableNumber, int capacity)
        {
            ITable table = null;
            if (type == "InsideTable")
            {
                table = new InsideTable(tableNumber, capacity);
            }
            else if (type == "OutsideTable")
            {
                table = new OutsideTable(tableNumber, capacity);
            }


            tables.Add(table);

            return string.Format(OutputMessages.TableAdded, tableNumber);
            //return $"Added table number {tableNumber} in the bakery";
        }

        public string ReserveTable(int numberOfPeople)
        {
            var table = this.tables.FirstOrDefault(t => t.IsReserved == false && t.Capacity >= numberOfPeople && numberOfPeople > 0);
            if (table is null)
            {
                return string.Format(OutputMessages.ReservationNotPossible, numberOfPeople);
                // return $"No available table for {numberOfPeople} people";


            }
            else
            {


                table.Reserve(numberOfPeople);
                //this.income += table.PricePerPerson * numberOfPeople;
                return string.Format(OutputMessages.TableReserved, table.TableNumber, numberOfPeople);
                //return $"Table {table.TableNumber} has been reserved for {numberOfPeople} people";
            }

        }

        public string OrderFood(int tableNumber, string foodName)
        {
            var table = this.tables.FirstOrDefault(t => t.TableNumber == tableNumber);

            if (table is null)
            {
                return string.Format(OutputMessages.WrongTableNumber, tableNumber);
                //return $"Could not find table {tableNumber}";
            }

            var food = this.bakedFoods.FirstOrDefault(f => f.Name == foodName);

            if (food is null)
            {
                return string.Format(OutputMessages.NonExistentFood, foodName);
                //return $"No {foodName} in the menu";
            }

            table.OrderFood(food);

            return string.Format(OutputMessages.FoodOrderSuccessful, tableNumber, foodName);
            //return $"Table {tableNumber} ordered {foodName}";
        }

        public string OrderDrink(int tableNumber, string drinkName, string drinkBrand)
        {
            var table = this.tables.FirstOrDefault(t => t.TableNumber == tableNumber);

            if (table is null)
            {
                return string.Format(OutputMessages.WrongTableNumber, tableNumber);
                //return $"Could not find table {tableNumber}";
            }

            var drink = this.drinks.FirstOrDefault(f => f.Name == drinkName && f.Brand == drinkBrand);

            if (drink is null)
            {
                return string.Format(OutputMessages.NonExistentDrink, drinkName, drinkBrand);
                //return $"There is no {drinkName} {drinkBrand} available";
            }

            table.OrderDrink(drink);

            return $"Table {tableNumber} ordered {drinkName} {drinkBrand}";
        }

        public string LeaveTable(int tableNumber)
        {
            var table = this.tables.FirstOrDefault(t => t.TableNumber == tableNumber);
            if (!(table is null))
            {

                var sb = new StringBuilder();
                sb.AppendLine($"Table: {tableNumber}");

                sb.AppendLine($"Bill: {table.GetBill():f2}");
                this.income += table.GetBill();

                table.Clear();
                return sb.ToString().TrimEnd();
            }

            return null;
        }

        public string GetFreeTablesInfo()
        {
            var sb = new StringBuilder();

            var freeTables = this.tables.Where(t => t.IsReserved == false).ToList();
            foreach (var table in freeTables)
            {
                sb.AppendLine(table.GetFreeTableInfo());
            }

            return sb.ToString().TrimEnd();
        }

        public string GetTotalIncome()
        {

            return string.Format(OutputMessages.TotalIncome, this.income);
        }
    }
}