﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Bakery.Models.BakedFoods.Contracts;
using Bakery.Models.Drinks.Contracts;
using Bakery.Models.Tables.Contracts;
using Bakery.Utilities.Messages;

namespace Bakery.Models.Tables
{
    public abstract class Table:ITable
    {
        private ICollection<IBakedFood> FoodOrders;
        private ICollection<IDrink> DrinkOrders;
        private int capacity;
        private int numberOfPeople;
        private bool isReserved=false;


        protected Table(int tableNumber, int capacity, decimal pricePerPerson)
        {
            this.FoodOrders=new List<IBakedFood>();
            this.DrinkOrders=new List<IDrink>();
            this.isReserved = false;
            this.TableNumber = tableNumber;
            this.Capacity = capacity;
            this.PricePerPerson = pricePerPerson;
        }

        public int TableNumber
        {
            get;
        }

        public int Capacity
        {
            get => this.capacity;
            private set
            {
                if (value < 0)
                {
                    throw new ArgumentException(ExceptionMessages.InvalidTableCapacity);
                }

                this.capacity = value;
            }
        }

        public int NumberOfPeople
        {
            get
            {
                return this.numberOfPeople;
            }
            private set
            {
                if (value <= 0)
                {
                    throw new ArgumentException(ExceptionMessages.InvalidNumberOfPeople);
                }

                this.numberOfPeople = value;
            }
        }

        public decimal PricePerPerson { get; }

        public bool IsReserved
        {
            get => this.isReserved;
            private set
            {
                this.isReserved = value;
            }
        }

        public decimal Price
        {
            get => this.PricePerPerson * this.numberOfPeople;
        }

        public void Reserve(int numberOfPeople)
        {
            this.numberOfPeople = numberOfPeople;
            this.isReserved = true;
        }

        public void OrderFood(IBakedFood food)
        {
            this.FoodOrders.Add(food);
        }

        public void OrderDrink(IDrink drink)
        {
            this.DrinkOrders.Add(drink);
        }

        public decimal GetBill()
        {
            return FoodOrders.Sum(food => food.Price) + DrinkOrders.Sum(drink => drink.Price)+this.Price;
        }

        public void Clear()
        {
            this.FoodOrders=new List<IBakedFood>();
            this.DrinkOrders=new List<IDrink>();

            this.isReserved=false;
            this.numberOfPeople = 0;
        }

        public string GetFreeTableInfo()
        {
            var sb = new StringBuilder();

            sb.AppendLine($"Table: {this.TableNumber}")
                .AppendLine($"Type: {this.GetType().Name}")
                .AppendLine($"Capacity: {this.capacity}")
                .AppendLine($"Price per Person: {this.PricePerPerson}");

            return sb.ToString().TrimEnd();
        }
    }
}