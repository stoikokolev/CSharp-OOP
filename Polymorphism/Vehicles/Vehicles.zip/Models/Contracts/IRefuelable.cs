﻿namespace Vehicles.Models.Contracts
{
    public interface IRefuelable
    {
        void Refuel(double fuelAmount);
    }
}
