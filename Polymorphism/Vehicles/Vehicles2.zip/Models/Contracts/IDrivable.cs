﻿namespace Vehicles.Models.Contracts
{
    public interface IDrivable
    {
        string Drive(double kilometers);
    }
}
