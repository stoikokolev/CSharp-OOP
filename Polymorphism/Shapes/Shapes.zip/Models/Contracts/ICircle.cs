﻿namespace Shapes.Models.Contracts
{
    public interface ICircle
    {
        double Radius { get; }
    }
}
