﻿namespace Shapes.Models.Contracts
{
    public interface IRectangle
    {
        double Width { get; }
        double Height { get; }
    }
}
