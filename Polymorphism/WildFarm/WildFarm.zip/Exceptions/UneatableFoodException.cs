﻿using System;

namespace WildFarm.Exceptions
{
    public class UneatableFoodException : Exception
    {
        //private const string DEF_EXC_MSG = "{0} does not eat {1}!";

        //public UneatableFoodException()
        //:base(DEF_EXC_MSG)
        //{
            
        //}

        public UneatableFoodException(string message)
        :base(message)
        {
            
        }
    }
}
