﻿namespace Raiding.IO.Contracts
{
    public interface IReader
    {
        string Read();
    }
}
