﻿namespace Logger.Models.Enumerations
{
    public enum Level
    {
        Info,
        Warning,
        Error,
        Critical,
        Fatal
    }
}
