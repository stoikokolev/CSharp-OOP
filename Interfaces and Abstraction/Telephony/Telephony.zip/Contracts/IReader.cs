﻿namespace Telephony.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
