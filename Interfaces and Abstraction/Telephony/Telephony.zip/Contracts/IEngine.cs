﻿namespace Telephony.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
