﻿namespace BorderControl.Contacts
{
    public interface IPet : ISociety, IBirthable
    {
        string Name { get; }
    }
}
