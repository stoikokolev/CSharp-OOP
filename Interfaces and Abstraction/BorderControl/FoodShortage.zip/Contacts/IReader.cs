﻿namespace BorderControl.Contacts
{
    public interface IReader
    {
        string Read();
    }
}
