﻿using BorderControl.Contacts;

namespace BorderControl
{
    public interface IPerson : ISociety
    {
        string Name { get; }
    }
}
