﻿namespace BorderControl.Contacts
{
    public interface IWriter
    {
        void Write(string text);

        void WriteLine(int text);
    }
}
