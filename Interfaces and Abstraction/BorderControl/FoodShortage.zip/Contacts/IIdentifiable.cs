﻿namespace BorderControl.Contacts
{
    public interface IIdentifiable
    {
        string ID { get; }
    }
}
