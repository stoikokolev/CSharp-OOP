﻿namespace BorderControl.Contacts
{
    public interface ISociety
    {
    }
}
