﻿namespace BorderControl.Contacts
{
    public interface IRabel : IBuyer
    {

        int Age { get; }

        string Group { get; }
    }
}
