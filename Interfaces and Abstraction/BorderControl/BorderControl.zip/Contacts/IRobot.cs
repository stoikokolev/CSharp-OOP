﻿namespace BorderControl.Contacts
{
    public interface IRobot : IIdentifiable
    {
        string Model { get; }
    }
}
