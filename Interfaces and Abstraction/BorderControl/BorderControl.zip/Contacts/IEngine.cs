﻿namespace BorderControl.Contacts
{
    public interface IEngine
    {
        void Run();
    }
}
