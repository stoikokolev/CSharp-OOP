﻿namespace BorderControl.Contacts
{
    public interface IBirthable : ISociety
    {
        string BirthDate { get; }
    }
}
