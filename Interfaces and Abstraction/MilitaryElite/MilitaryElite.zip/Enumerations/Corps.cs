﻿namespace MilitaryElite.Enumerations
{
    public enum Corps
    {
        Airforces,
        Marines
    }
}
