﻿namespace MilitaryElite.IO.Contracts
{
   public interface IReader
   {
       string ReadLine();
   }
}
